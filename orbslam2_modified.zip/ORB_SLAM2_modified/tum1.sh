Examples/RGB-D/rgbd_tum ./Vocabulary/ORBvoc.txt ./Examples/RGB-D/TUM1.yaml ~/Documents/data/rgbd_dataset_freiburg1_room ~/Documents/data/rgbd_dataset_freiburg1_room/associate.txt
